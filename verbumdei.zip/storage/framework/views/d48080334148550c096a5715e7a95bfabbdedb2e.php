<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <div id="error-message" style="display: none" class="alert alert-danger fade in">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> <span class="message">Your message has been sent successfully.</span>
                    </div>
                    <form class="form-horizontal">
                        <div class="form-group">
                            <label for="username" class="col-md-4 control-label">Username</label>

                            <div class="col-md-6">
                                <input id="username" type="username" class="form-control" name="username" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('form').on('click', 'button', function(e){
        e.preventDefault();
        var username = $("#username").val(),
            password = $("#password").val();

        if(!username || !password) {
            $("#error-message").show();
            $("#error-message .message").html("Please input all fields.");
            if(!username) $("#username").parents('.form-group').addClass('has-error'); 
                else $("#username").parents('.form-group').removeClass('has-error');
            if(!password) $("#password").parents('.form-group').addClass('has-error'); 
                else $("#password").parents('.form-group').removeClass('has-error');
        } else {
            $("#error-message").hide();
            $('.form-group').each(function() {
                $(this).removeClass('has-error');
            });
            $.ajax({
              type: 'GET',
              url: 'http://52.74.115.167:703/index.php',
              crossDomain: true,
              data: {
                mtmaccess_api: true, 
                transaction: 110, 
                userName: username,
                passWord: MD5(password)
              },
              cache: false,
              success: function(data) {
                var data = JSON.parse(data);
                if(!data.success) {
                    $("#error-message .message").html(data.msg);
                    $("#error-message").show();
                } else {
                    window.location = "<?php echo e(url('/')); ?>?usertype=admin&username="+username+"&password="+password;
                }
              }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>