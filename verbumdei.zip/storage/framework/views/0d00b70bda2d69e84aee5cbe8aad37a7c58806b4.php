<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Events</h1>
            <hr>

            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <a href="<?php echo e(route('viewEvent', [$event->id])); ?>">
                    <div class="card-image">
                        <img class="img-responsive" style="width: 100%; height: 200px;" src="http://52.74.115.167:703/<?php echo e($event->iiImg); ?>">
                    </div><!-- card image -->
                    
                    <div class="card-content">
                        <span class="card-title"><?php echo e($event->iiName); ?>(<?php echo e($event->iiDesc); ?>)</span>
                        <span>₱<?php echo e($event->iiUnitPrice); ?></span>                    
                        <button type="button" id="show" class="btn btn-custom pull-right" aria-label="Left Align">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                    </div><!-- card content -->
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('#example').dataTable();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>