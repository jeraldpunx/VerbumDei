<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>


    <!-- Styles -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(url('css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(url('css/myStyle.css')); ?>" rel="stylesheet" >
    
    <?php echo $__env->yieldContent('style'); ?>
    

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if(Session::has('username') && Session::get('usertype') == 'MERCHANT'): ?>
                            <li><a href="<?php echo e(url('admin/event')); ?>">Events</a></li>
                            <li><a href="<?php echo e(url('admin/kyc')); ?>">Members</a></li>
                        <?php elseif(Session::has('username') && Session::get('usertype') == 'CLIENT'): ?>
                            <li><a href="<?php echo e(url('event')); ?>">Events</a></li>
                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(!Session::has('username')): ?>
                            <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" style="text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Session::get('username')); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <?php if(Session::get('usertype') == 'CLIENT'): ?><a href="<?php echo e(url('profile')); ?>">Profile</a><?php endif; ?>
                                        <a href="<?php echo e(url('/logout')); ?>">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
        
    </div>

    <!-- Scripts -->
    <!-- <script src="<?php echo e(url('js/app.js')); ?>"></scaript> -->
    <script src="<?php echo e(url('js/jquery-3.2.0.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(url('js/myScript.js')); ?>"></script>
    <script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js">
    <script type="text/javascript">
        $(document).ready(function(){
            if(localStorage.getItem("communities") === null) {
                $.ajax({
                  type: 'GET',
                  url: 'http://52.74.115.167:703/index.php',
                  crossDomain: true,
                  data: {
                    mtmaccess_api: true, 
                    transaction: 20021
                  },
                  cache: false,
                  success: function(data) {
                    var data = JSON.parse(data);
                    if(data.success) {
                        localStorage.setItem('communities', JSON.stringify(data.result));
                    }
                  }
                });
            }
        });
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
