<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-5">
                            <div class="form-group">
                                <input type="text" name="first_name" class="form-control input-lg" placeholder="First Name" required>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-2">
                            <div class="form-group">
                                <input type="text" name="middle_name" id="middle_name" class="form-control input-lg" placeholder="Middle Name">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-5">
                            <div class="form-group">
                                <input type="text" name="last_name" id="last_name" class="form-control input-lg" placeholder="Last Name" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <!-- <select class="regions select2-form form-control" name="region" id="region"></select> -->
                        <input type="region" name="region" id="region" class="region form-control input-lg" placeholder="Region">
                    </div>
                    <div class="form-group">
                        <!-- <select class="province select2-form form-control" name="province" id="province"></select> -->
                        <input type="province" name="province" id="province" class="province form-control input-lg" placeholder="Province">
                    </div>
                    <div class="form-group">
                        <!-- <select class="city select2-form form-control" name="city" id="city"></select> -->
                        <input type="city" name="city" id="city" class="city form-control input-lg" placeholder="City">
                    </div>
                    <div class="form-group">
                        <!-- <select class="barangay select2-form form-control" name="barangay" id="barangay"></select> -->
                        <input type="barangay" name="barangay" id="barangay" class="barangay form-control input-lg" placeholder="Barangay">
                    </div>
                    <div class="form-group">
                        <input type="street_address" name="street_address" id="street_address" class="form-control input-lg" placeholder="Street Address">
                    </div>
                    
                    <div class="form-group">
                        <input type="contact" name="contact" id="contact" class="form-control input-lg" placeholder="Contact">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        var kycId = <?php echo e(Route::input('id')); ?>;
// http://52.74.115.167:703/index.php?mtmaccess_api=true&transaction=20020&userName=test6&imei=359861054037926
        $.ajax({
          type: 'GET',
          url: 'http://52.74.115.167:703/index.php',
          crossDomain: true,
          data: {
            mtmaccess_api: true, 
            transaction: 20020, 
            userName: "<?php echo e(Session::get('user')); ?>",
            passWord: "<?php echo e(Session::get('password')); ?>"
          },
          cache: false,
          success: function(data) {
            var data = JSON.parse(data);
            if(data.success) {
                console.log(data.result);
                $('#example').dataTable( {
                    "aaData": data.result,
                    'columns': [
                    { "data": null, render: function ( data, type, row ) {
                            return data.lastname+', '+data.firstname+' '+data.middlename;
                        }
                    },
                    { "data": null, render: function ( data, type, row ) {
                            return formatDate(data.birthDate);
                        } 
                    },
                    { "data": "gender" },
                    { "data": null, render: function ( data, type, row) {
                            return "<a class='btn btn-success' href='"+data.profileId+"'>Print</a>";
                        }
                    }
                    ],
                } );
            }
          }
        });       
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>