<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h3><a href="<?php echo e(url('event')); ?>">Events</a> / <?php echo e($event->iiName); ?></h3>
            <hr>
            <div class="col-md-9"> 
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h1><?php echo e($event->iiName); ?></h1>
                        <hr>
                        <center>
                            <img class="img-responsive" style="height: 200px;" src="http://52.74.115.167:703/<?php echo e($event->iiImg); ?>">
                        </center>
                        <br><br>
                        <p><b>Localtion:</b> <?php echo e($event->location); ?></p>
                        <p><b>Price:</b> <?php echo e($event->iiUnitPrice); ?></p>
                        <p>
                            <b>Description:</b><br>
                            <?php echo e($event->iiDesc); ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3"> 
                <div class="panel panel-default">
                    <div class="panel-body">
                        <center>
                            <a class="btn btn-success btn-block">JOIN</a>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        var kycId = <?php echo e(Route::input('id')); ?>;
// http://52.74.115.167:703/index.php?mtmaccess_api=true&transaction=20020&userName=test6&imei=359861054037926
        $.ajax({
          type: 'GET',
          url: 'http://52.74.115.167:703/index.php',
          crossDomain: true,
          data: {
            mtmaccess_api: true, 
            transaction: 20020, 
            userName: "<?php echo e(Session::get('user')); ?>",
            passWord: "<?php echo e(Session::get('password')); ?>"
          },
          cache: false,
          success: function(data) {
            var data = JSON.parse(data);
            if(data.success) {
                console.log(data.result);
                $('#example').dataTable( {
                    "aaData": data.result,
                    'columns': [
                    { "data": null, render: function ( data, type, row ) {
                            return data.lastname+', '+data.firstname+' '+data.middlename;
                        }
                    },
                    { "data": null, render: function ( data, type, row ) {
                            return formatDate(data.birthDate);
                        } 
                    },
                    { "data": "gender" },
                    { "data": null, render: function ( data, type, row) {
                            return "<a class='btn btn-success' href='"+data.profileId+"'>Print</a>";
                        }
                    }
                    ],
                } );
            }
          }
        });       
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>